package com.brd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CreateConnection {
	CustomerMasterTable x = null;

		Connection c=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 c= DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1521:orcl","sh","sh");
			System.out.println("Connection Stablished**********************");
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		public void getDetails(String a, String b, String c, String d, long e, String f, long g, String h, String i, String j, String k, String l, String m,String n, String o, String p)
		{
		PreparedStatement stmp=null;
		try{
		stmp =c.prepareStatement("insert into ROYCUSTOMERTABLE values(royid.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?");
		
		stmp.setString(1, a);
		stmp.setString(2, b);
		stmp.setString(3, c);
		stmp.setString(4, d);
		stmp.setLong(5, e);
		stmp.setString(6, f);
		stmp.setLong(7, g);
		stmp.setString(8, h);
		stmp.setString(9, i);
		stmp.setString(10, j);
		stmp.setString(11, k);
		stmp.setString(12, l);
		stmp.setString(13, m);
		stmp.setString(14, n);
		stmp.setString(15, o);
		stmp.setString(16, p);
		
		
		}catch(SQLException ex){
			ex.printStackTrace();
			
		}
		
		
		}
		
		
	
}

