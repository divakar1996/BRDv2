package com.brd;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
/*import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;*/
import java.util.Scanner;

public class Tester {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		BufferedReader bufferedReader = null;
		String line = null;

		CustomerMasterTable cmt = new CustomerMasterTable();
		

		Validation validation = new Validation();
		ErrorLog errorLog = new ErrorLog();
		boolean v1 = false;
		boolean v2 = false;
		boolean v3 = false;
		boolean v4 = false;
		boolean v5 = false;
		boolean v6 = false;
		boolean v7 = false;
		boolean v8 = false;
		boolean v9 = false;
		boolean fileFormat = false;
		/*
		 * boolean v10=false; boolean v11=false; boolean v12=false; boolean v13=false;
		 * boolean v14=false; boolean v15=false;
		 */

		int n;
		System.out.println("Please Enter the path in the given format e.g.: d:\\\\abc\\\\xyz\\\\");
		String fileLocation = scanner.nextLine();
		System.out.println("Enter file name");
		String fileName = scanner.nextLine();
		fileFormat = validation.fileFormat(fileName);

		if (fileFormat) {

			try {
				bufferedReader = new BufferedReader(new FileReader(fileLocation + fileName));

				System.out.println("File Loaded Successfully..............");

				System.out.println("CHOICE*******");
				System.out.println("1. R For record level Rejection\n2.F for File level Rejection");
				n = scanner.nextInt();

				try {
					while ((line = bufferedReader.readLine()) != null) {
						String[] token = line.split("~", -1);

						cmt.setCustomerCode(token[0]);
						cmt.setCustomerName(token[1]);
						cmt.setCustomerAddress1(token[2]);
						cmt.setCustomerAddress2(token[3]);
						cmt.setCustomerPinCode(Long.parseLong(token[4]));
						cmt.setEmailAddress(token[5]);
						cmt.setContactNumber(Long.parseLong(token[6]));
						cmt.setPrimaryContactPerson(token[7]);
						cmt.setRecordStatus(token[8]);
						cmt.setActiveInactiveFlag(token[9]);
						cmt.setCreateDate(token[10]);
						cmt.setCreatedBy(token[11]);
						cmt.setModifiedDate(token[12]);
						cmt.setModifiedBy(token[13]);
						cmt.setAuthorizedDate(token[14]);
						cmt.setAuthorizedBy(token[15]);

						v1 = validation.customerCodeValidation(cmt.getCustomerCode());
						v2 = validation.customerNameValidation(cmt.getCustomerName());
						v3 = validation.validationAddress1(cmt.getCustomerAddress1());
						v4 = validation.validationAddress2(cmt.getCustomerAddress2());
						v5 = validation.pinCodeValidation(cmt.getCustomerPinCode());
						v6 = validation.isValidEmailCheck(cmt.getEmailAddress());
						v7 = validation.primaryContactPersonValidation(cmt.getPrimaryContactPerson());
						v8 = validation.recordStatusValidation(cmt.getRecordStatus());
						v9 = validation.flagValidation(cmt.getActiveInactiveFlag());

						switch (n) {
						// FOR RECORD LEVEL REJECTION*********
						case 1:
							 if(v1 && v2 && v3 && v4 && v5 && v6 && v7 && v8 && v9) {
								 CreateConnection createConnection=new CreateConnection();
								 createConnection.getDetails(cmt.getCustomerCode(), cmt.getCustomerName(), c, d, e, f, g, h, i, j, k, l, m, n, o, p);
								 
								 
							}else {
							  }
							 

							break;
						// FOR FILE LEVEL REJECTION***********
						case 2:
							/*
							 * if( ) {
							 * 
							 * 
							 * }else {
							 * 
							 * }
							 */

							break;
						}

					}
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (FileNotFoundException e) {

				System.out.println("File Loading Error...............File not found.........");
			}

		}/* else {
			System.out.println("File Loading Error...............File not found.........");
		}*/
	}

	private static void () {
		// TODO Auto-generated method stub
		
	}

}
