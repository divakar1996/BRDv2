package com.brd;


import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ErrorLog {

	public void saveToFile(String line) {
		FileWriter fileWriter=null;
		PrintWriter printWriter=null;
		
		try {
			fileWriter=new FileWriter("D:\\BRD-File Upload\\errorlog.txt");
			printWriter=new PrintWriter(fileWriter);
			printWriter.write(line);
			printWriter.flush();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		finally{
			try {
				fileWriter.close();
				printWriter.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
			
		}
		
		

	}
}
