package com.brd;

public class Validation {
	//HashSet hs = new HashSet();
	//FILE FORMAT VALIDATION
public boolean fileFormat(String string) {
		if(string.endsWith(".txt")) {
			return true;
		}else return false;
	}
	//Customer Code Validation.
	public boolean customerCodeValidation(String cusCode) {
		if (cusCode.length() <= 10 && !cusCode.isEmpty() /*&& hs.add(cusCode)*/)
			return true;
		else
			return false;
	}
//Customer Name Validation
	public boolean customerNameValidation(String customerName) {
		if (customerName != null && customerName.length() <=30) {
			char[] character1 = customerName.toCharArray();
			for (char c : character1) {
				if (!(Character.isLetterOrDigit(c))) {
					String ch = Character.toString(c);
					if (!ch.equals("")) {
						return false;
					}
				}
			}
			return true;
		}
		return false;

	}

	//Address Validation
	public boolean validationAddress1(String add1) {
		if (add1.length() <= 100 && !add1.isEmpty())
			return true;
		else
			return false;
	}

	//Address 2 Validation
	public boolean validationAddress2(String add2) {
		if (add2.length() <= 100)
			return true;
		else
			return false;
	}

	// pincode validation
	public boolean pinCodeValidation(long pincode) {
		if (pincode != 0) {
			int count = 0;
			long r = 0;
			while (pincode > 0) {
				r = pincode % 10;
				pincode = pincode / 10;
				count++;
			}
			if (count != 6) {
				return false;
			} else {
				return true;
			}

		} else {
			return false;
		}

	}

	// email validation
	public boolean isValidEmailCheck(String email) {
		if (email != null && email.length() <= 100) {
			EmailValidator emailValidator = new EmailValidator();
			return emailValidator.validate(email);
		} else {
			return false;
		}

	}
//
	public boolean primaryContactPersonValidation(String primary) {
		if (primary.length() <= 100 && !primary.isEmpty())
			return true;
		else
			return false;

	}

	// record validation
	public boolean recordStatusValidation(String recordStatus) {
		recordStatus = recordStatus.toUpperCase();
		if (recordStatus != null && recordStatus.length() == 1) {
			if (recordStatus.length() == 1
					&& (recordStatus.equals("N") || recordStatus.equals("M")
							|| recordStatus.equals("D")
							|| recordStatus.equals("A") || recordStatus
								.equals("R"))) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}

	}

	// flag validation
	public boolean flagValidation(String flag) {
		if (flag != null && flag.length() == 1) {
			if (flag.length() == 1 && (flag.equals("A") || flag.equals("I"))) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public boolean createDatevalidation(String date) {
		if (!date.isEmpty())
			return true;
		else
			return false;

	}

	public boolean createByValidation(String by) {
		if (by.length() <= 30 && !by.isEmpty())
			return true;
		else
			return false;
	}

	public boolean modByvalidation(String by) {
		if (by.length() <= 30)
			return true;
		else
			return false;

	}

	public boolean authBYValidation(String auth) {
		if (auth.length() <= 30)
			return true;
		else
			return false;
	}
	
}
